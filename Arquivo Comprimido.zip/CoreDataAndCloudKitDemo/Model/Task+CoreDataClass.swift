//
//  Task+CoreDataClass.swift
//  CoreDataAndCloudKitDemo
//
//  Created by Vitor Gledison Oliveira de Souza on 02/12/21.
//
//

import Foundation
import CoreData

@objc(Task)
public class Task: NSManagedObject {

}
